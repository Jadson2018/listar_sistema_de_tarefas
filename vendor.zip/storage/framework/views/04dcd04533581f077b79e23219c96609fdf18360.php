<?php $__env->startSection('content'); ?>
 <?php if($errors->all()): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="alert alert-danger aviso-erro" role="alert"><?php echo e(__($error)); ?></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<div class="containernativo">
<div class="box">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="">
                <div class="nativo"><img src="<?php echo e(url('listarlogo.png')); ?>" class="logo"></div>
                <div class="">
                    <form method="POST" action="<?php echo e(route('usuarios.login')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="form-group row">

                            <div class="col-md-12">
                                <p><input id="email" type="email" class="form-control entrada" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email" autofocus placeholder="E-mail"></p>

                            </div>
                        </div>

                        <div class="form-group row">

                            <div class="col-md-12">
                                <p><input id="password" type="password" class="form-control" name="password" required autocomplete="current-password" placeholder="Senha"></p>

                                <button type="submit" class="btn btn-info btn-block">
                                    <?php echo e(__('entrar')); ?>

                                </button>
                            </div>
                        </div>

                        
                        <div class="form-group row mb-0">
                            <div class="col-md-12 offset-md-12">
                                <div class="cadastro">
                                   <p>Não possui um cadastro?</p>
                                   <a href="<?php echo e(route('usuarios.addusuario')); ?>"><input type="button" value="cadastre-se" class="btn btn-dark"></a>
                                 </div>

                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\sistemadelistagem\resources\views/auth/login.blade.php ENDPATH**/ ?>