<?php echo e($slot); ?>

<?php /**PATH C:\Users\usuário\Desktop\host laravel\sistemadelistagem\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>