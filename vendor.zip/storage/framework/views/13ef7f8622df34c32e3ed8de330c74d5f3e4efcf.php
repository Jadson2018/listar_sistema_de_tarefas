

<?php $__env->startSection('content'); ?>
         <?php if($errors->all()): ?>
              <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                 <div class="alert alert-danger aviso-erro" role="alert"><?php echo e(__($error)); ?></div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
         <?php endif; ?>
          <div class="containernativo">    
          <div class="box">
          <h1 class="font-padrao">Cadastro</h1>
          <form action="<?php echo e(route('usuarios.salvar')); ?>" method="POST" class="formulario-login">
            <?php echo csrf_field(); ?>
              <p><input type="text" placeholder="nome" name="name" class="form-control"></p>
              <p><input placeholder="E-mail" type="email" name="email" class="form-control" value="<?php echo e(old('email')); ?>"></p>
              <p><input placeholder="Senha" type="password" name="password" class="form-control"><p>
              <input type="submit" value="cadastrar" class="btn btn-info btn-block">
            </form>
            </div>
           </div>
<?php $__env->stopSection(); ?> 
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\usuário\Desktop\host laravel\sistemadelistagem\resources\views/cadastro.blade.php ENDPATH**/ ?>