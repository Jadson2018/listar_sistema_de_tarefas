<?php 
phpinfo();
